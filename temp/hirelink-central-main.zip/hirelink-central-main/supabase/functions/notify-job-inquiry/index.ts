import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple in-memory rate limiting (resets on function cold start)
// Limits: 5 requests per IP per 10 minutes, 3 requests per email per hour
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

function isRateLimited(key: string, maxRequests: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(key);
  
  if (!entry || now > entry.resetAt) {
    rateLimitStore.set(key, { count: 1, resetAt: now + windowMs });
    return false;
  }
  
  if (entry.count >= maxRequests) {
    return true;
  }
  
  entry.count++;
  return false;
}

function getClientIP(req: Request): string {
  // Check common headers for real IP (behind proxies/load balancers)
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  const realIP = req.headers.get("x-real-ip");
  if (realIP) {
    return realIP;
  }
  return "unknown";
}

// Input validation schema (manual implementation for Deno compatibility)
function validateJobInquiry(data: unknown): { success: true; data: JobInquiryNotification } | { success: false; error: string } {
  if (!data || typeof data !== 'object') {
    return { success: false, error: "Invalid request body" };
  }

  const obj = data as Record<string, unknown>;

  // Required string fields with max lengths
  const stringFields: { name: string; required: boolean; maxLength: number }[] = [
    { name: 'companyName', required: true, maxLength: 200 },
    { name: 'contactPerson', required: true, maxLength: 100 },
    { name: 'email', required: true, maxLength: 255 },
    { name: 'country', required: true, maxLength: 100 },
    { name: 'location', required: true, maxLength: 100 },
    { name: 'industry', required: true, maxLength: 100 },
    { name: 'phone', required: false, maxLength: 30 },
    { name: 'jobDetails', required: false, maxLength: 2000 },
  ];

  for (const field of stringFields) {
    const value = obj[field.name];
    if (field.required && (typeof value !== 'string' || value.trim().length === 0)) {
      return { success: false, error: `${field.name} is required` };
    }
    if (value !== undefined && value !== null && typeof value !== 'string') {
      return { success: false, error: `${field.name} must be a string` };
    }
    if (typeof value === 'string' && value.length > field.maxLength) {
      return { success: false, error: `${field.name} must be less than ${field.maxLength} characters` };
    }
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (typeof obj.email === 'string' && !emailRegex.test(obj.email)) {
    return { success: false, error: "Invalid email format" };
  }

  // Validate positions (must be a positive number)
  if (typeof obj.positions !== 'number' || obj.positions < 1 || obj.positions > 1000) {
    return { success: false, error: "positions must be a number between 1 and 1000" };
  }

  return {
    success: true,
    data: {
      companyName: String(obj.companyName).trim(),
      contactPerson: String(obj.contactPerson).trim(),
      email: String(obj.email).trim().toLowerCase(),
      phone: obj.phone ? String(obj.phone).trim() : undefined,
      country: String(obj.country).trim(),
      location: String(obj.location).trim(),
      industry: String(obj.industry).trim(),
      positions: Number(obj.positions),
      jobDetails: obj.jobDetails ? String(obj.jobDetails).trim() : undefined,
    }
  };
}

// HTML escape function to prevent XSS in email templates
function escapeHtml(text: string): string {
  const htmlEntities: Record<string, string> = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  };
  return text.replace(/[&<>"']/g, (char) => htmlEntities[char] || char);
}

interface JobInquiryNotification {
  companyName: string;
  contactPerson: string;
  email: string;
  phone?: string;
  country: string;
  location: string;
  industry: string;
  positions: number;
  jobDetails?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Rate limit by IP first (before parsing body)
    const clientIP = getClientIP(req);
    const ipRateLimitKey = `ip:${clientIP}`;
    
    if (isRateLimited(ipRateLimitKey, 5, 10 * 60 * 1000)) { // 5 requests per 10 minutes
      console.warn(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: "Too many requests. Please try again later." }),
        {
          status: 429,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const rawData = await req.json();
    console.log("Received job inquiry notification request from IP:", clientIP);

    // Validate input
    const validationResult = validateJobInquiry(rawData);
    if (!validationResult.success) {
      console.error("Validation failed:", validationResult.error);
      return new Response(
        JSON.stringify({ error: validationResult.error }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const data = validationResult.data;

    // Rate limit by email (stricter - 3 per hour)
    const emailRateLimitKey = `email:${data.email.toLowerCase()}`;
    if (isRateLimited(emailRateLimitKey, 3, 60 * 60 * 1000)) { // 3 requests per hour
      console.warn(`Rate limit exceeded for email: ${data.email}`);
      return new Response(
        JSON.stringify({ error: "Too many requests for this email. Please try again later." }),
        {
          status: 429,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Get admin email from environment or use default
    const adminEmail = Deno.env.get("ADMIN_NOTIFICATION_EMAIL") || "admin@example.com";

    // Escape all user-provided data for HTML templates
    const safeCompanyName = escapeHtml(data.companyName);
    const safeContactPerson = escapeHtml(data.contactPerson);
    const safeEmail = escapeHtml(data.email);
    const safePhone = data.phone ? escapeHtml(data.phone) : '';
    const safeCountry = escapeHtml(data.country);
    const safeLocation = escapeHtml(data.location);
    const safeIndustry = escapeHtml(data.industry);
    const safeJobDetails = data.jobDetails ? escapeHtml(data.jobDetails) : '';

    // Send notification to admin
    const adminEmailResponse = await resend.emails.send({
      from: "Job Portal <onboarding@resend.dev>",
      to: [adminEmail],
      subject: `New Job Inquiry from ${safeCompanyName}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #2563eb;">New Job Inquiry Received</h1>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin-top: 0; color: #1f2937;">Company Details</h2>
            <p><strong>Company:</strong> ${safeCompanyName}</p>
            <p><strong>Contact Person:</strong> ${safeContactPerson}</p>
            <p><strong>Email:</strong> <a href="mailto:${safeEmail}">${safeEmail}</a></p>
            ${safePhone ? `<p><strong>Phone:</strong> ${safePhone}</p>` : ''}
          </div>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin-top: 0; color: #1f2937;">Job Requirements</h2>
            <p><strong>Industry:</strong> ${safeIndustry}</p>
            <p><strong>Location:</strong> ${safeLocation}, ${safeCountry}</p>
            <p><strong>Positions Needed:</strong> ${data.positions}</p>
            ${safeJobDetails ? `<p><strong>Details:</strong> ${safeJobDetails}</p>` : ''}
          </div>
          
          <p style="color: #6b7280; font-size: 14px;">
            Please log in to the admin dashboard to manage this inquiry.
          </p>
        </div>
      `,
    });

    console.log("Admin notification email sent:", adminEmailResponse);

    // Send confirmation to the company
    const confirmationEmailResponse = await resend.emails.send({
      from: "Job Portal <onboarding@resend.dev>",
      to: [data.email],
      subject: "We received your job inquiry!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #2563eb;">Thank You for Your Inquiry!</h1>
          
          <p>Dear ${safeContactPerson},</p>
          
          <p>We have received your job inquiry for <strong>${data.positions} position(s)</strong> in the <strong>${safeIndustry}</strong> sector.</p>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="margin-top: 0; color: #1f2937;">Your Inquiry Summary</h2>
            <p><strong>Company:</strong> ${safeCompanyName}</p>
            <p><strong>Location:</strong> ${safeLocation}, ${safeCountry}</p>
            <p><strong>Positions:</strong> ${data.positions}</p>
          </div>
          
          <p>Our team will review your requirements and get back to you within 1-2 business days.</p>
          
          <p>Best regards,<br>The Job Portal Team</p>
        </div>
      `,
    });

    console.log("Confirmation email sent:", confirmationEmailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        adminEmail: adminEmailResponse, 
        confirmationEmail: confirmationEmailResponse 
      }), 
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in notify-job-inquiry function:", error);
    return new Response(
      JSON.stringify({ error: "An error occurred processing your request" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
