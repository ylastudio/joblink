-- Add a permissive policy to allow public submissions to candidates table
CREATE POLICY "Anyone can submit their candidate application"
ON public.candidates
FOR INSERT
WITH CHECK (true);

-- Create storage bucket for CV uploads
INSERT INTO storage.buckets (id, name, public)
VALUES ('candidate-cvs', 'candidate-cvs', false)
ON CONFLICT (id) DO NOTHING;

-- Allow anyone to upload CVs to the bucket
CREATE POLICY "Anyone can upload CVs"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'candidate-cvs');

-- Only admins can view/download CVs
CREATE POLICY "Admins can view CVs"
ON storage.objects
FOR SELECT
USING (bucket_id = 'candidate-cvs' AND public.has_role(auth.uid(), 'admin'::app_role));

-- Only admins can delete CVs
CREATE POLICY "Admins can delete CVs"
ON storage.objects
FOR DELETE
USING (bucket_id = 'candidate-cvs' AND public.has_role(auth.uid(), 'admin'::app_role));