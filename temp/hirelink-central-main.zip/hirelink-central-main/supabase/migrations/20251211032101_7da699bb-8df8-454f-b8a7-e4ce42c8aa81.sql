-- Create candidates table
CREATE TABLE public.candidates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  nationality TEXT NOT NULL,
  current_location TEXT,
  date_of_birth DATE,
  skills TEXT[],
  experience_years INTEGER DEFAULT 0,
  preferred_industries TEXT[],
  preferred_countries TEXT[],
  cv_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.candidates ENABLE ROW LEVEL SECURITY;

-- Only admins can view candidates (contains PII)
CREATE POLICY "Only admins can view candidates"
ON public.candidates
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can insert candidates
CREATE POLICY "Admins can insert candidates"
ON public.candidates
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update candidates
CREATE POLICY "Admins can update candidates"
ON public.candidates
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete candidates
CREATE POLICY "Admins can delete candidates"
ON public.candidates
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_candidates_updated_at
BEFORE UPDATE ON public.candidates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();