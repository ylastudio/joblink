-- Drop the existing overly permissive SELECT policy
DROP POLICY IF EXISTS "Public can view own submissions" ON public.job_inquiries;

-- Create a new policy that only allows admins to view job inquiries
CREATE POLICY "Only admins can view job inquiries" 
ON public.job_inquiries 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

-- Also add policies for admin to update/delete if needed
CREATE POLICY "Admins can update job inquiries" 
ON public.job_inquiries 
FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete job inquiries" 
ON public.job_inquiries 
FOR DELETE 
USING (public.has_role(auth.uid(), 'admin'));