-- Create table for recruiter job inquiries
CREATE TABLE public.job_inquiries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  industry TEXT NOT NULL,
  positions INTEGER NOT NULL DEFAULT 1,
  job_details TEXT,
  location TEXT NOT NULL,
  country TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.job_inquiries ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (public form submission)
CREATE POLICY "Anyone can submit job inquiries"
ON public.job_inquiries
FOR INSERT
WITH CHECK (true);

-- Only authenticated admins would be able to view (we'll handle this later if needed)
CREATE POLICY "Public can view own submissions"
ON public.job_inquiries
FOR SELECT
USING (true);